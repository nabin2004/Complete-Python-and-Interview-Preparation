
# def view_contacts(contacts):
#     print('-------- view_contacts --------')
#     for index, contact in enumerate(contacts):
#         name, number = contact
#         print(f"{index + 1} {name}{number}")

def view_contacts(contacts):
    print('-------- view_contacts --------')
    for index, contact in enumerate(contacts):
        name, number = contact
        print("{:<2} {:<10} {}".format(index + 1, name, number))     

def add_contact(contacts):
    print('-------- add_contact --------')
    name = input("Enter contact name: ")
    number = input("Enter contact number: ")
    contacts.append((name, number))
    print(f"{name} - {number} has been added into the contact.")

def delete_contact(contacts):
    print('-------- delete_contact --------')
    view_contacts(contacts)
    index = int(input("Enter the ID of the contact to delete: ")) - 1
    if 0 <= index < len(contacts):
        name, number = contacts.pop(index)
        print(f"{name} - {number} has been removed from the contact.")
    else:
        print("Invalid contact ID.")

def main(contacts=[("Satish", "123"), ("Rita", "321")]):
    while True:
        choice = input('Select an operation:\n'
                       'v view contacts\n'
                       'a add contacts\n'
                       'd delete contact\n'
                       'q quit\n\n'
                       'Enter choice (v/a/d/q - to quit): ')
        if choice == 'v':
            view_contacts(contacts)
        elif choice == 'a':
            add_contact(contacts)
        elif choice == 'd':
            delete_contact(contacts)
        elif choice == 'q':
            print('-------- goodbye --------')
            break
        else:
            print('-------- Invalid_choice --------')
            print("Try again...")


if __name__ == "__main__":
    main()
