class BankAccount:
    def __init__(self, balance, account):
        self.balance = balance 
        self.account = account

    def get_account(self):
        return self.account

    def get_balance(self):
        return self.balance

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount > self.balance:
            raise ValueError("Insufficient balance")
        self.balance -= amount

    def transfer(self, amount, acc):
        if amount > self.balance:
            raise ValueError("Insufficient balance")
        self.withdraw(amount)
        acc.deposit(amount)
