from L8_library_bank import BankAccount

account1 = BankAccount(100, "Nabin")
account2 = BankAccount(100, "Raju")

account1.balance = account2.balance = 100

account1.withdraw(40)
account2.withdraw(40)

print("Account {} balance: {}".format(account1.get_account(), account1.get_balance()))
print("Account {} balance: {}".format(account2.get_account(), account2.get_balance()))

account1.deposit(20)
account2.deposit(20)

print("Account {} balance: {}".format(account1.get_account(), account1.get_balance()))
print("Account {} balance: {}".format(account2.get_account(), account2.get_balance()))

account2.transfer(20, account1)

print("Account {} balance: {}".format(account1.get_account(), account1.get_balance()))
print("Account {} balance: {}".format(account2.get_account(), account2.get_balance()))
