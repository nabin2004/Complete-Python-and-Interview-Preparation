class BMI:
    def __init__(self):
        self.__weight = 0
        self.__height = 0

    def set_weight(self, weight):
        self.__weight = weight

    def set_height(self, height):
        self.__height = height

    def __cal_BMI(self):
        return self.__weight / (self.__height ** 2)

    def display_BMI(self):
        bmi = self.__cal_BMI()
        print("BMI: {:.2f}".format(bmi))
